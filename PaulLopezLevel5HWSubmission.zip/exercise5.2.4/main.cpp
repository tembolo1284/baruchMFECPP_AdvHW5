#include <iostream>
#include <boost/regex.hpp>
#include <regex>

int main() {

	boost::regex myReg10("/");
	std::string s3 = "2016/3/15";


	boost::sregex_token_iterator iter1(s3.begin(), s3.end(), myReg10, 0);
	boost::sregex_token_iterator iter1_end;

	boost::sregex_token_iterator iter2(s3.begin(), s3.end(), myReg10, -1);
	boost::sregex_token_iterator iter2_end;

	std::cout << "extracting dashes: ";
	while (iter1 != iter1_end) {
		std::cout << *iter1++ << " ";
	}

	std::cout << "\nextracting numbers: ";
	while (iter2 != iter2_end) {
		std::cout << *iter2++ << ", ";
	}

	return 0;
}