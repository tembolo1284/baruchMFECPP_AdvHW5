#include <iostream>
#include <string>
#include <cassert>
#include <boost/bimap/bimap.hpp>
#include <boost/bimap/list_of.hpp>
#include <boost/bimap/unordered_set_of.hpp>
#include <boost/bimap/multiset_of.hpp>
#include <boost/uuid/uuid.hpp>
#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>

using namespace boost::bimaps;

struct DomainName {};
struct IpAddress {};

template <class MapType> 
void PrintMap(const MapType& map) {
	std::cout << std::endl;
	for (auto i = map.begin(), iend = map.end(); i != iend; i++) {
		std::cout << i->left << ", " << i->right << std::endl;
	}
}

int main() {
	typedef bimap<
		unordered_set_of< tagged< std::string, DomainName> >,
		unordered_set_of< tagged< boost::uuids::uuid, IpAddress> >,
		list_of_relation> DNS;

	DNS dbExample1;
	DNS dbExample2;

	using namespace boost::uuids;

	string_generator stringGen;
	uuid id1 = stringGen("11111111-1111-1111-1111-111111111111");
	uuid id2 = stringGen("9876543210ABCDEFabcdef0123456789");
	uuid id3 = stringGen("88888888-8888-8888-8888-888888888888");

	dbExample1.push_back(DNS::value_type("www.datasim.nl", id1));
	dbExample1.push_back(DNS::value_type("www.chase.com", id2));
	dbExample1.push_back(DNS::value_type("www.bankofamerica.com", id3));

	DNS::map_by<DomainName>::const_iterator dName = dbExample1.by<DomainName>().find("www.datasim.nl");
	DNS::map_by<IpAddress>::const_iterator IpAdd = dbExample1.by<IpAddress>().find(id2);

	if (dName != dbExample1.by<DomainName>().end()) {
		std::cout  << "www.datasim.nl has IP Address: " << dName->get<IpAddress>() << std::endl;
	}

	if (IpAdd != dbExample1.by<IpAddress>().end()) {
		std::cout << id2 << " has DNS Name: " << IpAdd->get<DomainName>() << std::endl;
	}

	//for (auto i = dbExample1.begin(); i != dbExample1.end(); i++) {
	//	std::cout << i->left << ", " << i->right << std::endl;
	//}
	PrintMap(dbExample1);

	return 0;
}