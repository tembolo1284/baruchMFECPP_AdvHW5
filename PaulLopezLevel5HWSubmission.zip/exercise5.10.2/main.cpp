#include <iostream>
#include <string>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <algorithm>
#include <functional>


namespace ublas = boost::numeric::ublas;


int main() {
	ublas::matrix<double, ublas::column_major, ublas::bounded_array<double, 9> > mat1(3, 3);
	ublas::matrix<double, ublas::column_major, ublas::bounded_array<double, 9> > mat2(3, 3);
	ublas::matrix<double, ublas::column_major, ublas::bounded_array<double, 9> > mat3(3, 3);
	ublas::matrix<double, ublas::column_major, ublas::bounded_array<double, 9> > mat4(3, 3);
	ublas::matrix<double, ublas::column_major, ublas::bounded_array<double, 9> > zeroes(3, 3);
	ublas::matrix<double, ublas::column_major, ublas::bounded_array<double, 9> > identity(3, 3);

	for (int row = 0; row < mat1.size1(); row++) {
		for (int cols = 0; cols < mat1.size2(); cols++) {
			mat1(row, cols) = row + cols;
			mat2(row, cols) = row - cols;
			mat3(row, cols) = 0;
			mat4(row, cols) = 0;
			zeroes(row, cols) = 0;
			if (row == cols) {
				identity(row, cols) = 1;
			}
			else {
				identity(row, cols) = 0;
			}
		}
	}

	
	mat3 = mat1 + identity;

	mat4 = mat2 - mat3;

	

	std::cout << "mat1: " << mat1 << std::endl;
	std::cout << "mat2: " << mat2 << std::endl;
	std::cout << "mat3 = mat1 + identity: " << mat3 << std::endl;
	std::cout << "mat4 = mat2 - mat3: " << mat4 << std::endl;
	std::cout << "zeroes: " << zeroes << std::endl;
	std::cout << "identity: " << identity << std::endl;

	identity.resize(3, 2, true);

	std::cout << "identity after resize(): " << identity << std::endl;

	return 0;
}