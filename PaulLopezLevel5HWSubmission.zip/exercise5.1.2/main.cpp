#include <iostream>
#include <string>
#include <boost/algorithm/string/classification.hpp>
#include <boost/algorithm/string.hpp>
using namespace boost::algorithm;

void passwordChecker(std::string s) {
	//check len is >= 8 chars
	if (s.length() < 8) {
		std::cout << "Password is too short. Needs to be at least 8 chars." << std::endl;
		return;
	}
	int upperCnt{};//check at least one char is uppercase
	upperCnt = std::count_if(s.begin(), s.end(),[](unsigned char c) { 
		return std::isupper(c); 
		});
	if (upperCnt == 0) {
		std::cout << "Password needs at least one uppercase char." << std::endl;
		return;
	}
	int blankCnt{}; //check there are no blanks
	blankCnt = std::count_if(s.begin(), s.end(), [](unsigned char c) {
		return std::isblank(c);
		});
	if (blankCnt > 0) {
		std::cout << "Password is not allowed to have spaces." << std::endl;
		return;
	}

	int ctrlCnt{}; //check there are no control characters
	ctrlCnt = std::count_if(s.begin(), s.end(), [](unsigned char c) {
		return std::iscntrl(c);
		});
	if (ctrlCnt > 0) {
		std::cout << "Password is not allowed to have control characters." << std::endl;
		return;
	}
	else {
		std::cout << "Password looks good!" << std::endl;
	}
}

int main() {
	std::string str1 = " |abd1 234\*| ";

	boost::algorithm::trim_if(str1, boost::algorithm::is_digit() || boost::algorithm::is_alpha());
	std::cout << "str1 after digit or letter trim : " << str1 << std::endl; //it seems to understand everything as a number because 
	//it translates the chars to numbers.

	boost::algorithm::trim_if(str1, boost::algorithm::is_digit() && !(boost::algorithm::is_alpha()));
	std::cout << "str1 after digit and NOT letter trim : " << str1 << std::endl; //same result as above

	boost::algorithm::trim_if(str1, boost::algorithm::is_alpha());
	std::cout << "str1 after letter trim : " << str1 << std::endl;//same result
	//all gave back |abd1 234*|

	/*It must contain at least 8 characters.
		It must contain a combination of digits and characters.
		At least one character must be upper case.
		No control characters allowed.
		No spaces allowed. */
	std::string pwd1("DanielDuffy1952");
	std::string pwd2("DanielDuffy");
	std::string pwd3("U19520829");
	std::string pwd4("thisisnocaps");
	std::string pwd5("12345678988");
	std::string pwd("19520829U");

	passwordChecker(pwd1);
	passwordChecker(pwd2);
	passwordChecker(pwd3);
	passwordChecker(pwd4);
	passwordChecker(pwd5);
	passwordChecker(pwd);
	


	return 0;

}