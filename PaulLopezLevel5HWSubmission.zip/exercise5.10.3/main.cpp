#include <iostream>
#include <string>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <boost/numeric/ublas/triangular.hpp>
#include <algorithm>
#include <functional>
#include <complex>


namespace ublas = boost::numeric::ublas;

int main() {
	ublas::matrix<std::complex<double>, ublas::column_major, ublas::bounded_array<std::complex<double>, 9> > mat1(3, 3);
	ublas::matrix<double> dense1(3, 3);
	ublas::triangular_matrix<double, ublas::lower, ublas::column_major, ublas::bounded_array<double, 9> > lower1(3, 3);
	ublas::triangular_matrix<double, ublas::upper, ublas::column_major, ublas::bounded_array<double, 9> > upper1(3, 3);
	std::complex<double> c1(1, 5);
	//std::cout << c1.real()<< ", " << c1.imag() << std::endl;

	for (int row = 0; row < mat1.size1(); row++) {
		for (int cols = 0; cols < mat1.size2(); cols++) {
			dense1(row, cols) = 2.75;
			if (row >= cols) {
				mat1(row, cols) = c1;  //lower triangular matrix
				lower1(row, cols) = row + cols;
			}

			if (row <= cols) {
				upper1(row, cols) = row - cols;
			}
		}
	}

	std::cout << "mat1: " << mat1 << std::endl;
	std::cout << "lower1: " << lower1 << std::endl;
	std::cout << "upper1: " << upper1 << std::endl;
	std::cout << "\ndense1: " << dense1 << std::endl;

	//lower triangular matrix adaptor
	ublas::triangular_adaptor<ublas::matrix<double>, ublas::lower> l1(dense1);
	std::cout << "l1: " << l1 << std::endl;
	ublas::triangular_adaptor<ublas::matrix<double>, ublas::upper> u1(dense1);
	std::cout << "u1: " << u1 << std::endl;

	return 0;
}