#include <iostream>
#include <boost/regex.hpp>


int main() {
	boost::regex mySearchReg("(rain)|(Spain)");
	std::string myText("The rain in Spain stays mainly on the plain");
	boost::smatch what;


	if (boost::regex_search(myText, what, mySearchReg)) {
		std::cout << what[0] << '\n';
		std::cout << what[1] << "_" << what[2] << '\n';
	}

	return 0;
}