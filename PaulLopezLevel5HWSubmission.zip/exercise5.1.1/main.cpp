#include <boost/algorithm/string.hpp>
#include <boost/algorithm/cxx11/any_of.hpp>
#include <boost/assign/list_of.hpp>
#include <iostream>
#include <string>

using namespace boost::algorithm;
/* This is for exericse 5.1.1 my BOOST is still not working right for new workbooks */

int main() {
	std::string s1 = "    |hello to you my boost still no workie how sad|    ";
	boost::algorithm::trim(s1);
	std::cout << "s1 = " << s1 << std::endl;
	std::cout << "s1 copy = " << boost::algorithm::trim_copy(s1) << std::endl;
	std::string filter = "A";

	
	std::string s2 = "AAAA    |hello to you my boost still no workie how sad|    AAA";
	boost::algorithm::trim_if(s2, boost::algorithm::is_any_of("A |")); 
	std::cout << "s2 = " << s2 << std::endl;
														
	
	std::string subStr1 = "hello to you";
	std::string subStr2 = "HELLO TO YOU";
	std::string subStr3 = "how sad";
	std::string subStr4 = "HOW SAD";

	std::cout << std::boolalpha << starts_with(s2, subStr1) << std::endl;
	std::cout << starts_with(s2, subStr2) << std::endl;
	std::cout << ends_with(s2, subStr3) << std::endl;
	std::cout << ends_with(s2, subStr4) << std::endl;

	std::cout << equals(subStr1, subStr2) << std::endl; //test if strings are equal
	
	return 0;

}