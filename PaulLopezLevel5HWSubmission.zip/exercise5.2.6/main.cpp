#include <iostream>
#include <string>
#include <boost/regex.hpp>


//This is for exercise 5.2.6
int main() {
	boost::regex ecmaReg ("((\\+|-)?[[:digit:]]+)(\\.(([[:digit:]]+)?))?((e|E)((\\+|-)?)[[:digit:]]+)?");

	//first part before the e|E part allows positive or negative digits, and decimals

	//((e|E)((\\+|-)?)[[:digit:]]+)? this part allows numbers to the e and then more numbers. e part (with the numbers) is optional
	std::string s1 = "5e10";
	std::string s2 = "-50e10";
	std::string s3 = "-50e";
	std::string s4 = "-hello";
	std::string s5 = "101.125";
	std::string s6 = "55^250";
	std::string s7 = "100.75e100";


	std::cout << std::boolalpha << boost::regex_match(s1, ecmaReg) << '\n'; //true

	auto s1D = stod(s1); //valid result convert to double
	std::cout << std::boolalpha << boost::regex_match(s2, ecmaReg) << '\n'; //true
	std::cout << std::boolalpha << boost::regex_match(s3, ecmaReg) << '\n'; //false
	std::cout << std::boolalpha << boost::regex_match(s4, ecmaReg) << '\n'; //false
	std::cout << std::boolalpha << boost::regex_match(s5, ecmaReg) << '\n'; //true
	std::cout << std::boolalpha << boost::regex_match(s6, ecmaReg) << '\n'; //false
	std::cout << std::boolalpha << boost::regex_match(s7, ecmaReg) << '\n'; //true
	return 0;
}