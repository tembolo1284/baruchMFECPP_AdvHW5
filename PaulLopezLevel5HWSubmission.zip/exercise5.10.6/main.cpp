#include <iostream>
#include <string>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <algorithm>
#include <functional>

namespace ublas = boost::numeric::ublas;

int main() {
	
	ublas::matrix<double> mat1(3, 3);
	for (int i = 0; i < mat1.size1(); i++) {
		for (int j = 0; j < mat1.size2(); j++) {
			mat1(i, j) = i + j;
		}
	}

	std::cout << "mat1: " << mat1 << std::endl;
	//matrix row and column proxy
	ublas::matrix_row<ublas::matrix<double>> rowProx1(mat1, 2);
	ublas::matrix_row<ublas::matrix<double>> colProx1(mat1, 1);

	std::cout << "row 2: " << rowProx1 << ", index = " << rowProx1.index() << std::endl;
	std::cout << "column 1: " << colProx1 << ", index = " << colProx1.index() << std::endl;

	//matrix range proxy
	ublas::matrix_range<ublas::matrix<double>> rangeProx1(mat1, ublas::range(0, 2), ublas::range(0, 2));
	std::cout << "range proxy: " << rangeProx1 << std::endl; // mat1 is 3x3 and the range is the top lh corner matrix 2x2

	
	//matrix slice proxy
	ublas::matrix_slice<ublas::matrix<double> >	sliceProx1(mat1, ublas::slice(0, 1, 3), ublas::slice(0, 1, 3)); //should output entire matrix

	std::cout << "matrix slice: " << sliceProx1 << std::endl;

	return 0;
}