#include <iostream>
#include <string>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <boost/numeric/ublas/triangular.hpp>
#include <boost/numeric/ublas/vector.hpp>
#include <algorithm>
#include <functional>
#include <complex>

namespace ublas = boost::numeric::ublas;

int main() {
	

	ublas::vector<double> vec1(3);
	ublas::vector<double> vec2(3);
	ublas::matrix<double> mat1(3, 3);
	ublas::matrix<double> mat2(3, 3);

	for (int i = 0; i < vec1.size(); i++) {
		vec1[i] = i + 1.0;
		vec2[i] = i + 2.0;
	}

	for (int row = 0; row < mat1.size1(); row++) {
		for (int col = 0; col < mat1.size2(); col++) {
			mat1(row, col) = row + col + 1.0;
		}
	}

	std::cout << "vec1: " << vec1 << std::endl;
	std::cout << "vec2: " << vec2 << std::endl;
	auto innerProd = ublas::inner_prod(vec1, vec2);
	std::cout << "\ninner product: " << innerProd << std::endl;

	auto outerProd = ublas::outer_prod(vec1, vec2);
	std::cout << "outer product: " << outerProd << std::endl;

	auto addVecs = vec1 + vec2;
	std::cout << "addition: " << addVecs << std::endl;

	auto subtractVecs = vec1 - vec2;
	std::cout << "subtraction: " << subtractVecs << std::endl;

	std::cout << "L1 norm of vec1: " << ublas::norm_1(vec1) << std::endl;
	std::cout << "L2 norm of vec1: " << ublas::norm_2(vec1) << std::endl;
	std::cout << "L-infinity norm of vec2: " << ublas::norm_inf(vec2) << std::endl;

	std::cout << "mat1: " << mat1 << std::endl;
	std::cout << "L1 norm of mat1: " << ublas::norm_1(mat1) << std::endl;
	std::cout << "max norm of mat1: " << ublas::norm_inf(mat1) << std::endl;

	std::cout << "mat1 * vec1: " << ublas::prod(mat1,vec1) << std::endl;
	std::cout << "vec1 * mat1: " << ublas::prod(vec1, mat1) << std::endl;


	return 0;
}