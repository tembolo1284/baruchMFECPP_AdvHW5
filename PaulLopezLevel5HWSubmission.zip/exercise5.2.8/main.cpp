#include <iostream>
#include <stdio.h>
#include <vector>
#include <map>
#include <list>
#include <string>
#include <cstddef>
#include <boost/date_time/gregorian/gregorian.hpp>
#include <boost/algorithm/string.hpp>
#include <fstream>
#include <ios>

using Data = std::tuple<boost::gregorian::date, std::vector<double>>;
using ResultSet = std::list<Data>;

boost::gregorian::date createDate(const std::string& yyyy, const std::string& mm, const std::string& dd) {
	int year = boost::lexical_cast<int>(yyyy);
	int month = boost::lexical_cast<int>(mm);
	int day = boost::lexical_cast<int>(dd);

	return boost::gregorian::date(year, month, day);
}

template <typename T>
std::vector<T> createArray(const std::vector<std::string>& datalist, int startIdx ) {
	std::vector<T> result;
	for (std::size_t i = startIdx; i < datalist.size(); i++) {
		result.push_back(boost::lexical_cast<T>(datalist[i]));
	}

	return result;
}

void spaceRemover(std::string& str) {
	boost::algorithm::trim(str); //remove space before and after
	boost::algorithm::trim_if(str, boost::is_any_of(" ")); //remove spaces everywhere else
}

template <typename Date, typename T>
ResultSet ReadCSVFile(const char* filename) {
	std::vector<std::string> rowArray;
	std::string line;
	ResultSet outputFromData;
	Data row;

	try {
		std::fstream file(filename, std::ios::in | std::ios::app);

		if (!file.is_open()) {
			std::cout << "Can't open file!" << std::endl;
		}

		//header
		std::getline(file, line);
		std::cout << line << std::endl;

		while (std::getline(file, line)) {
			spaceRemover(line);
			if (line.size() > 0) {
				boost::split(rowArray, line, boost::is_any_of(",-")); 

				row = std::make_tuple(createDate(rowArray[0], rowArray[1], rowArray[2]), createArray<T>(rowArray, 3));
				outputFromData.push_back(row);
			}
		}
	}
	catch (std::exception& e) {
		std::cout << "Error: " << e.what() << std::endl;
	}
	return outputFromData;
}

int main() {

	try {

		const char* fileName = "test.txt";// "C:\\Users\\niklo\\OneDrive\\Desktop\\CPP-Workspace\\HWsAdvLevel5Baruch\\exercise2\\exercise5.1.3 - Copy\\test.txt";
		ResultSet dataFromCSV = ReadCSVFile<boost::gregorian::date, double>(fileName);

		//crude print out
		for (auto iter = dataFromCSV.begin(); iter != dataFromCSV.end(); iter++) {
			std::cout << std::get<0>(*iter) << "* ";
			std::cout << std::get<1>(*iter)[0] << ", " << std::get<1>(*iter)[1] << ", " << std::get<1>(*iter)[2] << ", "
				<< std::get<1>(*iter)[3] << ", " << std::get<1>(*iter)[4] << ", " << std::get<1>(*iter)[5] << ", " << std::endl;

		}
	}
	catch (std::exception& e) {
		std::cout << "Error: " << e.what() << std::endl;
	}
	return 0;

}