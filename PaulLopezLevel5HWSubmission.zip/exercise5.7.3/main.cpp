#include <iostream>
#include <string>
#include <cassert>
#include <boost/bimap/bimap.hpp>
#include <boost/bimap/list_of.hpp>
#include <boost/bimap/unordered_set_of.hpp>
#include <boost/bimap/multiset_of.hpp>
#include <boost/uuid/uuid.hpp>
#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <tuple>


using namespace boost::bimaps;

int main() {

	typedef bimap<
		multiset_of<std::string>,  //author
		set_of<std::string>, //book title
		with_info<double>  //price of book
	> BMType;

	typedef BMType::value_type Book;

	typedef bimap<
		multiset_of<std::string>,  //author
		set_of<std::string>, //book title
		with_info<std::tuple<std::string,double>>  //abstract and price of book
	> BMTupleType;

	typedef BMTupleType::value_type Book2;

	BMType bm1;
	BMTupleType bmtt1;

	bm1.insert(Book("Prof Duffy", "Super PDE Solver Guide", 150.00));
	bm1.insert(Book("Prof Duffy", "Super PDE Solver Guide part 2", 350.00));
	bm1.insert(Book("Prof Duffy2", "Super Boost Book 1", 109.95));
	bm1.insert(Book("Prof Duffy3", "Super PDE Solver Guide", 450.00)); //doesn't work

	std::cout << bm1.right.at("Super PDE Solver Guide") << std::endl;

	std::cout << std::endl;
	BMType::left_iterator i = bm1.left.find("Prof Duffy2");
	std::cout << i->info << std::endl;
	
	bmtt1.insert(Book2("Sir Duffy", "Super PDE Solver Guide", std::make_tuple("For phd greatness",150.75)));
	bmtt1.insert(Book2("Sir Duffy", "Super PDE Solver Guide part 2", std::make_tuple("for Abel prize",350.00)));

	std::cout << bmtt1.right.at("Super PDE Solver Guide") << std::endl;

	std::cout << std::endl;
	BMTupleType::left_iterator j = bmtt1.left.find("Sir Duffy");
	std::cout << "Author: " << j->first << ", Title: " << j->second << std::endl;
	auto tup = j->info;
	std::cout << "Abstract: " << std::get<0>(tup) << ", Price: " << std::get<1>(tup) << std::endl;
	
return 0;
}