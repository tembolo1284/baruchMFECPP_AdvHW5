#include <iostream>
#include <boost/signals2/signal.hpp>


struct MyStruct {
    double val;
    MyStruct(double v) { 
        val = v; 
    }
    void modify(double newValue) {
       val = newValue;
       std::cout << "A third slot " << val << std::endl;
   }
};


void slotFreeFunc() {
    std::cout << "Free Func slot." << std::endl;
}

struct SlotFuncObj {
    void operator () () {
        std::cout << "Func Obj slot." << std::endl;
    }

};
int main() {
/*a) Create a signal and create slots using lambda functions, 
free functions and function objects. Connect the slots to the signal and emit the signal. Examine the output.
b) Create the following class:*/
    auto lambdaSlot = []() {
        std::cout << "lambda slot." << std::endl;
    };
    SlotFuncObj funcObj;
    MyStruct struct1(100.0);
    boost::signals2::signal<void()> signal1; //create signal

    signal1.connect(&slotFreeFunc);//connect slots
    signal1.connect(funcObj);
    signal1.connect(lambdaSlot);
    signal1.connect(std::bind(&MyStruct::modify,&struct1,105.55)); //connect myStruct with 105.55 as input for modify function

    signal1();//emit signal
    /////////////////////////
    signal1.disconnect(&slotFreeFunc);
    signal1.disconnect(&funcObj);
    signal1.disconnect(&lambdaSlot);

    signal1(); 

    // Define potential emitters
    boost::signals2::signal<void()> signalA;
    boost::signals2::signal<void()> signalB;
    boost::signals2::signal<void()> signalC;
    boost::signals2::signal<void()> signalD;

    // Define slots
    auto slotB = []() {std::cout << "Slot B called by B\n " << std::endl; };
    auto slotC = []() {std::cout << "Slot C called by C\n " << std::endl; };
    auto slotD1 = []() {std::cout << "Slot D1 called by D\n " << std::endl; };
    auto slotD2 = []() {std::cout << "Slot D2 called by D\n " << std::endl; };

    /*Signal B connected to signal A.
        Signal C connected to signal B.
        Signal D connected to signal C.
        Slot B connected to signal B.
        Slot C connected to signal C.
        Slot D1 connected to signal D.
        Slot D2 connected to signal D.*/

    signalA.connect(signalB);
    signalB.connect(signalC);
    signalC.connect(signalD);

    signalB.connect(slotB);
    signalC.connect(slotC);
    signalD.connect(slotD1);
    signalD.connect(slotD2);

    signalA(); //cool cascade effect

    signalB.disconnect(&signalC); //works fine for me
    
    signalA();

    
return 0;
}