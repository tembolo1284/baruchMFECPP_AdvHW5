#include <iostream>
#include <string>
#include <vector>
#include <queue>

int main() {
	std::vector<int> vec1{ 10,5,20,30,25,7,40 };
	std::priority_queue<int> pq1;
	std::priority_queue<int, std::vector<int>, std::greater<int>> pq2;

	for (int elem : vec1) {
		pq1.push(elem);
	}

	std::cout << "priority queue contents: ";
	while (!pq1.empty()) {
		std::cout << pq1.top() << ' ';
		pq1.pop();
	}

	for (int elem : vec1) {
		pq2.push(elem);
	}


	std::cout << "\npriority queue contents with std::greater<int>: ";
	while (!pq2.empty()) {
		std::cout << pq2.top() << ' ';
		pq2.pop();
	}


	auto cmp = [](int left, int right)->bool {
		return (left > right);
	};

	std::priority_queue<int, std::vector<int>, decltype(cmp)> pq3(cmp);
	for (int elem : vec1) {
		pq3.push(elem);
	}

	std::cout << "\npriority queue contents using lambda function: ";
	while (!pq3.empty()) {
		std::cout << pq3.top() << ' ';
		pq3.pop();
	}


	return 0;
}