#include <iostream>
#include <functional>
#include <boost/functional/hash.hpp>

template <typename T>
void hash_value(std::size_t& seed, const T& val) {
    boost::hash_combine(seed, val);
    std::cout << "value: " << val << ", seed: " << seed << std::endl;
}

template <typename T, typename... Types>
void hash_value(std::size_t& seed, const T& val, const Types&... args) {
    boost::hash_combine(seed, val);
    std::cout << "value: " << val << ", seed: " << seed << std::endl;
    hash_value(seed, args...);
}

template <typename... Types>
std::size_t hash_value(const Types&... args) {
    std::size_t seed = 0;
    hash_value(seed, args...);
    return seed;
}

int main() {
    std::size_t seed = 0;
    std::string str1 = "This is a string.";
    std::string str2 = "This is another string.";
    double d = 2.75;
    int a = 5; 
    bool what = true;

    hash_value(seed, str1);
    hash_value(seed, str1, a);


   std::cout << "hash value output 1 param: " << hash_value(str2);
   std::cout << "\nhash value output multiple params: " << hash_value(str2, a, d, what); //the bool will show up as 1 not true

	return 0;
}