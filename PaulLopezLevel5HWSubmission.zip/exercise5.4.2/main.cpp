#include <iostream>
#include <boost/functional/hash.hpp>
#include "Point.hpp"
#include "Shape.hpp"
#include "Line.hpp"
#include <list>

using namespace std;
using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;

//custom hash function
struct PointHash: 

std::unary_function <Point, std::size_t> {

	std::size_t operator() (const Point & pt) const {
		std::size_t seed = 0;
		boost::hash_combine(seed, pt.X());
		boost::hash_combine(seed, pt.Y());
		//std::cout << "\n" << seed << std::endl;
		return seed;
	}
};

int main() {
	Point p1(1, 2);
	Point p2(2, -1.5);
	Point p3;
	Point p4(-1, 0);
	Line l1(p1, p2);
	Line l2(p2, p3);

	
	std::cout << "Hash value for p1: " << hash_value(p1) << std::endl;
	std::cout << "Hash value for l1: " << hash_value(l1) << std::endl;
	

	std::list<Point> ptList;
	ptList.push_back(p1);
	ptList.push_back(p2);
	ptList.push_back(p3);
	ptList.push_back(p4);

	std::cout << "hash range of pt list: " << boost::hash_range(ptList.begin(), ptList.end());

	
	PointHash ph1;
	std::cout << "\npointHash struct hash output: " << ph1(p1) << std::endl;
	



	return 0;
}