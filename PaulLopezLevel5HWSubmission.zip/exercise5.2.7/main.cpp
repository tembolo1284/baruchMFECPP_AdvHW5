#include <iostream>
#include <boost/regex.hpp>
#include <regex>

//hello

int main() {
	std::string text("Quick brown fox");
	std::regex vowels("a|e|i|o|u");

	//Use std::regex_replace to produce the following output :
	//Q**ck br*wn f*x



	std::regex_replace(std::ostreambuf_iterator<char>(std::cout),
		text.begin(), text.end(), vowels, "*");

	return 0;
}