#include <iostream>
#include <string>
#include <cstddef>
#include <iomanip>
#include <boost/functional/hash.hpp>
#include <unordered_set>

template <typename T>
void hash_value(std::size_t& seed, const T& val) {
	boost::hash_combine(seed, val);
	std::cout << "value: " << val << ", seed: " << seed << std::endl;
}

template <typename T, typename... Types>
void hash_value(std::size_t& seed, const T& val, const Types&... args) {
	boost::hash_combine(seed, val);
	std::cout << "value: " << val << ", seed: " << seed << std::endl;
	hash_value(seed, args...);
}

template <typename... Types>
std::size_t hash_value(const Types&... args) {
	std::size_t seed = 0;
	hash_value(seed, args...);
	return seed;
}

struct S {
	double d1;
	double d2;
	S(const double& a, const double& b) : d1(a), d2(b) {}
};

class HashS {
public:
	std::size_t operator() (const S& s) const {
		return hash_value(s.d1, s.d2);
	}

};

std::size_t hash_value(const S& s) {
	std::size_t seed = 0;
	boost::hash_combine(seed, s.d1);
	boost::hash_combine(seed, s.d2);

	return seed;
}

class EqualPredicate {
public:
	bool operator() (const S& lhs, const S& rhs) const {
		return (rhs.d1 == lhs.d1 && rhs.d2 == lhs.d2);
	}

};
template <typename Key, typename Hash, typename EqPred>
void BucketInformation(const std::unordered_set<Key, Hash, EqPred>& b) {
	int buckCount = b.bucket_count();
	std::cout << "Num of buckets = " << buckCount << std::endl;
	std::cout << "Max num of buckets possible = " << b.max_bucket_count() << std::endl;
	std::cout << "Current load factor = " << b.load_factor() << std::endl;
	std::cout << "Max load factor possible = " << b.max_load_factor() << std::endl;
	
	//bucket by bucket info
	for (int i = 0; i < buckCount; i++) {
		std::cout << "Size of bucket " << i << " = " << b.bucket_size(i) << std::endl;
	}
}


/*c) Show the size of each bucket.
d) Rehash the container so that it has a bucket size of at least some given size.*/

int main() {

	std::unordered_set<S, HashS, EqualPredicate> unOrdSet;
	S s1(2.5, 5.5);
	S s2(-2.5, -5.5);
	S s3(1.75, 1.25);
	S s4(0.0, 0.125);
	S s5(1.1, 3.1);

	unOrdSet.insert(s1);
	unOrdSet.insert(s2);
	unOrdSet.insert(s3);
	unOrdSet.insert(s4);
	unOrdSet.insert(s5);


	auto valFound = unOrdSet.find(s1);
	if (valFound != unOrdSet.end()) {
		std::cout << "Vals found " << (*valFound).d1 << ", " << (*valFound).d2 << std::endl;
	}
	else {
		std::cout << "No Vals found." << "\n\n";
	}

	BucketInformation<S, HashS, EqualPredicate>(unOrdSet);

	for (auto elem : unOrdSet) {
		std::cout << "First elem = " << elem.d1 << ", Second elem = " << elem.d2 << std::endl;
	}

	unOrdSet.rehash(13); // unOrdSet.size() / unOrdSet.max_load_factor());
	BucketInformation<S, HashS, EqualPredicate>(unOrdSet); //and we call it again to see how the rehashing changed things.
	
	for (auto elem : unOrdSet) {
		std::cout << "First elem = " << elem.d1 << ", Second elem = " << elem.d2 << std::endl;
	}

	return 0;
}