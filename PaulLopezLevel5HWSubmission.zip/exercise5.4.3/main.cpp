#include <iostream>
#include <functional>
#include <boost/functional/hash.hpp>
#include <chrono>
#include "Point.hpp"
#include "Shape.hpp"
#include <set>
#include <unordered_set>


using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;

template<typename T, typename U>
std::size_t stdHashFunc(T t1, U t2) {
	std::size_t h1 = std::hash<T>{}(t1);
	std::size_t h2 = std::hash<U>{}(t2);
	return h1 ^ (h2 << 1);
};

//custom hash function
struct PointHash :
	std::unary_function <Point, std::size_t> {
	std::size_t operator() (const Point& pt) const {
		std::size_t seed = 0;
		boost::hash_combine(seed, pt.X());
		boost::hash_combine(seed, pt.Y());
		//std::cout << "\n" << seed << std::endl;
		return seed;
	}
};

int main() {
	Point p1(1, 1);
	Point p2(-2, 3);
	Point p3(-1, 5);
	PointHash ph1;
	PointHash ph2;
	PointHash ph3;

	std::size_t p1Hash = ph1(p1);
	std::size_t p2Hash = ph2(p2);
	std::size_t p3Hash = ph3(p3);

	std::size_t p1STDHash = stdHashFunc(p1.X(), p1.Y());
	std::size_t p2STDHash = stdHashFunc(p2.X(), p2.Y());
	std::size_t p3STDHash = stdHashFunc(p3.X(), p3.Y());

	std::unordered_multiset<double> unOrdMultSet1;
	std::chrono::time_point <std::chrono::system_clock> start, end;
	start = std::chrono::system_clock::now();

	//a few inserts for our good health
	unOrdMultSet1.insert(p1STDHash);
	unOrdMultSet1.emplace(p2STDHash);
	unOrdMultSet1.insert(p3STDHash);

	//print set
	std::cout << "unOrdMultSet1: ";
	for (auto elem : unOrdMultSet1) {
		std::cout << elem << ", ";
	}
	
	//some delete action
	unOrdMultSet1.erase(p1STDHash);
	unOrdMultSet1.clear();
	std::cout << "\nMulti Set size = " << unOrdMultSet1.size() << std::endl;

	end = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds = end - start;
	std::time_t end_time = std::chrono::system_clock::to_time_t(end);

	std::cout << "Finished computation at elapsed time: "	<< elapsed_seconds.count() << "s\n\n";

	///////////////////////

	std::unordered_multiset<double> unOrdMultSet2;
	std::chrono::time_point <std::chrono::system_clock> start2, end2;
	start2 = std::chrono::system_clock::now();

	//a few inserts
	unOrdMultSet2.insert(p1Hash);
	unOrdMultSet2.emplace(p2Hash);
	unOrdMultSet2.insert(p3Hash);

	//print set
	std::cout << "unOrdMultSet1: ";
	for (auto elem : unOrdMultSet2) {
		std::cout << elem << ", ";
	}

	//some deleting
	unOrdMultSet2.erase(p1Hash);
	unOrdMultSet2.clear();
	std::cout << "\nMulti Set size = " << unOrdMultSet2.size() << std::endl;

	end2 = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds2 = end2 - start2;
	std::time_t end_time2 = std::chrono::system_clock::to_time_t(end2);

	std::cout << "Finished computation at elapsed time: "	<< elapsed_seconds2.count() << "s\n\n";

	//////////

	std::multiset<double> multSet;
	std::chrono::time_point <std::chrono::system_clock> start3, end3;
	start3 = std::chrono::system_clock::now();

	//a few inserts for our good health
	multSet.insert(p1STDHash);
	multSet.emplace(p2STDHash);
	multSet.insert(p3STDHash);

	//print set
	std::cout << "MultSet: ";
	for (auto elem : multSet) {
		std::cout << elem << ", ";
	}

	//some delete action
	multSet.erase(p1STDHash);
	multSet.clear();
	std::cout << "\nMulti Set size = " << multSet.size() << std::endl;

	end3 = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds3 = end3 - start3;
	std::time_t end_time3 = std::chrono::system_clock::to_time_t(end3);

	std::cout << "Finished computation at elapsed time: "	<< elapsed_seconds3.count() << "s\n\n";

return 0;
}