#include <iostream>
#include <string>
#include <cstddef>
#include <iomanip>
#include <boost/functional/hash.hpp>
#include <functional>

template<typename T>
std::size_t stdHashFunc(T& t) {
    //std::size_t operator()(S const& s) const noexcept {
        std::size_t h = std::hash<T>{}(t);
        //std::size_t h2 = std::hash<std::string>{}(s.last_name);
        //return h1 ^ (h2 << 1); // or use boost::hash_combine
        return h;
};

template<typename T>
std::size_t boostHashFunc(T& t) {
    //std::size_t operator()(S const& s) const noexcept {
    std::size_t h = boost::hash<T>{}(t);
    //std::size_t h2 = std::hash<std::string>{}(s.last_name);
    //return h1 ^ (h2 << 1); // or use boost::hash_combine
    return h;
};

template<typename T, typename U>
std::size_t HashFuncCombine(T& t, U& u) {
    std::size_t h1 = std::hash<T>{}(t);
    std::size_t h2 = std::hash<U>{}(u);
    return h1 ^ (h2 << 1);
}


int main() {
/*Create two generic functions to hash arbitrary data types using Boost and C++11.

b) Test the functions using integers, strings, pointers, std::numeric_limits<long>::max().

c) Create two hashes h1 and h2 of two strings and then compute h1 ^ (h2 << 1).*/
    std::string str1 = "This is a string.";
    int a = 5;
    int* b = &a;
    auto maxNum = std::numeric_limits<long>::max();

    std::cout << "stdHashFunc for string: " << stdHashFunc(str1) << std::endl;
    std::cout << "boostHashFunc for string: " << boostHashFunc(str1) << std::endl;

    std::cout << "stdHashFunc for int: " << stdHashFunc(a) << std::endl;
    std::cout << "boostHashFunc for int: " << boostHashFunc(a) << std::endl;

    std::cout << "stdHashFunc for pointer: " << stdHashFunc(b) << std::endl;
    std::cout << "boostHashFunc for pointer: " << boostHashFunc(b) << std::endl;

    std::cout << "stdHashFunc for std::numeric_limits<long>::max(): " << stdHashFunc(maxNum) << std::endl;
    std::cout << "boostHashFunc for std::numeric_limits<long>::max(): " << boostHashFunc(maxNum) << std::endl;

    std::string str2 = "This is also a string I think.";

    std::cout << "\nOutput for h1 ^ (h2 << 1): " << HashFuncCombine(str1, str2) << std::endl;
    

return 0;
}