#include <iostream>
#include <boost/regex.hpp>
#include <boost/algorithm/string.hpp>
#include <string>

int main() {

	std::string sA("a = 1, b = 2, c = 3");
	boost::regex myReg(",");
	std::vector<std::string> result;
	std::map<std::string, int> mapResult;


	boost::sregex_token_iterator iter1(sA.begin(), sA.end(), myReg, -1);
	boost::sregex_token_iterator iter1_end;

	boost::trim_if(sA, boost::is_any_of(" "));

	while (iter1 != iter1_end) {
		//std::cout << *iter1++ << "\n";
		boost::split(result, *iter1++, boost::is_any_of("="));
		mapResult[result[0]] = stoi(result[1]);
	}

	for (auto elem : mapResult) {
		std::cout << "First elem: " << elem.first << ", second elem: " << elem.second << std::endl;
	}
	

	return 0;
}