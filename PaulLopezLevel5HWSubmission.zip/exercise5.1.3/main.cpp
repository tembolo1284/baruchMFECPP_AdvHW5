#include <iostream>
#include <string>
#include <vector>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp> 
#include <boost/date_time/gregorian/gregorian.hpp>


using namespace boost::algorithm;

boost::gregorian::date dateFormatter(const std::string& yyyy, const std::string& mm, const std::string& dd) {
		int year = boost::lexical_cast<int>(yyyy);
		int month = boost::lexical_cast<int>(mm);
		int day = boost::lexical_cast<int>(dd);

	return boost::gregorian::date(year, month, day);
}

int main() {
std::string sA("1,2,3,4/5/9*56");
std::vector<std::string> result;
boost::split(result, sA, boost::is_any_of(",/*"));

for (auto elem : result) {
	std::cout << elem << ", ";
}
std::cout << "\n";
std::string sA2 = boost::algorithm::join(result, "/");
std::cout << "sA2: " << sA2 << std::endl;

std::string dateExample("2015-12-31");
std::vector<std::string> resultBoostDate;
boost::split(resultBoostDate, dateExample, boost::is_any_of("-"));

for (auto elem : resultBoostDate) {
	std::cout << elem << ", ";
}
std::string input1 = resultBoostDate[0];
std::string input2 = resultBoostDate[1];
std::string input3 = resultBoostDate[2];

boost::gregorian::date resultBoost = dateFormatter(input1, input2, input3);

std::cout << "\n" << boost::gregorian::to_simple_string(resultBoost) << std::endl;;

std::string slot1{ "port = 23" };
std::string slot2{ "pin = 87" };
std::string slot3{ "value = 34.4" };

boost::algorithm::trim_if(slot1, boost::is_any_of(" "));
boost::algorithm::trim_if(slot2, boost::is_any_of(" "));
boost::algorithm::trim_if(slot3, boost::is_any_of(" "));


std::vector<std::string> mapVecSplitter1;
boost::split(mapVecSplitter1, slot1, boost::is_any_of("="));

std::vector<std::string> mapVecSplitter2;
boost::split(mapVecSplitter2, slot2, boost::is_any_of("="));

std::vector<std::string> mapVecSplitter3;
boost::split(mapVecSplitter3, slot3, boost::is_any_of("="));

std::map<std::string, double> mapResult;

mapResult[mapVecSplitter1[0]] = stod(mapVecSplitter1[1]);
mapResult[mapVecSplitter2[0]] = stod(mapVecSplitter2[1]);
mapResult[mapVecSplitter3[0]] = stod(mapVecSplitter3[1]);

for (auto& elem: mapResult) {
	std::cout << "Key: " << elem.first << ",Value: " << elem.second << std::endl;
}


return 0;

}