#include <iostream>
#include <boost/signals2/signal.hpp>
struct BootstrapCheck {
    // Iterate in slots and return first 'false'
    // value; otherwise, 'true'
    typedef bool result_type;
    template <typename InputIterator>
    bool operator()(InputIterator first, InputIterator last) const {
        while (first != last) {
            if (!*first)
                return false;
            ++first;
        }
        return true;
    }
};

struct MyStruct {
    double val;
    MyStruct(double v) {
        val = v;
    }
    bool modify(double newValue) {
        val = newValue;
        std::cout << "A third slot " << val << std::endl;
        return true;
    }
};


bool slotFreeFunc1() {
    std::cout << "Free Func1 slot." << std::endl;
    return true;
}
bool slotFreeFunc2() {
    std::cout << "Free Func2 slot." << std::endl;
    return false;
}
bool slotFreeFunc3() {
    std::cout << "Free Func3 slot." << std::endl;
    return true;
}

struct SlotFuncObj {
    bool operator () () {
        std::cout << "Func Obj slot." << std::endl;
        return true;
    }
};


int main() {

    auto lambdaSlot = []() {
        std::cout << "lambda slot." << std::endl;
    };
	boost::signals2::signal<bool (), BootstrapCheck> sig;
    MyStruct struct1(100.0);
    SlotFuncObj funcObj;

   
    sig.connect(&slotFreeFunc1); //return true
    sig.connect(&slotFreeFunc2);// return false
    sig.connect(&slotFreeFunc3); //return true
    //sig.connect(lambdaSlot); //return true
    //sig.connect(std::bind(&MyStruct::modify, &struct1, 105.55)); 

    sig();//stops after func2....never prints func3. That's deliciously useful.
return 0;
}