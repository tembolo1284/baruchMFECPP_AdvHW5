#include <iostream>
#include <string>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <algorithm>
#include <functional>


namespace ublas = boost::numeric::ublas;

int main() {

	ublas::vector<double> vec1(3);

	for (int i = 0; i < vec1.size(); i++) {
			vec1(i) = i * 2.0;
	}
	vec1[1] = 1.0;
	std::cout << "vec1: \n" << vec1 << std::endl;
	ublas::vector<double> vec2(vec1.size());
	for (int i = 0; i < vec2.size(); i++) {
		vec2(i) = 2.0;
	}
	ublas::vector<double> vec3(vec2);
	std::cout << "vec2: \n" << vec2 << std::endl;

	vec1 += vec2;
	std::cout << "vec1 = vec1 + vec2: \n" << vec1 << std::endl;

	vec1 *= 2.5;
	std::cout << "vec1 = vec1 * 2.5: \n" << vec1 << std::endl;

	vec1 -= vec3;
	std::cout << "vec1 = vec1 - vec3: \n" << vec1 << std::endl;

	ublas::vector<double> vec4(vec1.size()); 
	std::cout << "vec4: \n" << vec4 << std::endl; //will spit out garbage values
	
	std::transform(vec1.begin(), vec1.end(), vec2.begin(), vec4.begin(), std::multiplies<>{});

	std::cout << "vec4 after transform: \n" << vec4 << std::endl; //[6, 11, 26

	ublas::vector<double> vecScalar(100, 5.0);
	std::cout << "\nvecScalar: \n" << vecScalar << std::endl; 



	return 0;
}