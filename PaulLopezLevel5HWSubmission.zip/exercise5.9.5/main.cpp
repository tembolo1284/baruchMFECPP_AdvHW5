#include <iostream>
#include <string>
#include <boost/signals2/signal.hpp>
#include <boost/function.hpp>
#include <list>

typedef boost::function<void(double)> FunctionType;

class Subject {
    // The notifier (Observable)in Publisher-Subscriber pattern
    private:
        //std::list<FunctionType> attentionList;
        boost::signals2::signal<void (double)> attentionSig;
    public:
        Subject() { attentionSig = boost::signals2::signal<void (double)>(); }

        void AddObserver(int group, const FunctionType& ft) {
            attentionSig.connect(group, ft);
        }

       
        void ChangeEvent(double x) {
            attentionSig(x);
        }
};

void MathsWhiz(double x) {
    std::cout << "MathsWhiz slot gives: " << x << std::endl;
}

void Database(double x) {
    std::cout << "Database slot gives: " << x << std::endl;
}

 
void CPrint(double x) {
    std::cout << "C function slot print: " << x << std::endl;
}

struct Print {
    void operator() (double x) {
        std::cout << "I am a printer " << x << std::endl;
    }
};

int main() {

    // Create the notifier
   Subject mySubject;


    // Create the attention list
    Print myPrint;
    MathsWhiz(10.0);
    Database(5.5);

    mySubject.AddObserver(1, myPrint);
    mySubject.AddObserver(2,&MathsWhiz);
    mySubject.AddObserver(3,&Database);
    mySubject.AddObserver(4,&CPrint);

    // Trigger the event
    std::cout << "Give the value (double): "; 
    double val; 
    std::cin >> val;
    mySubject.ChangeEvent(val);


	return 0;
}