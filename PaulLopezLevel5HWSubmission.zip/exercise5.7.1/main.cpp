#include <iostream>
#include <string>
#include <boost/bimap.hpp>

int main() {

	typedef boost::bimap<std::string, int> PersonBiMap;
	typedef PersonBiMap::value_type position;

	PersonBiMap people;

	people.insert( position("Bill Murray", 60));
	people.insert( position("Tom Hanks", 65));
	people.insert(position("Tom Cruise", 55));

	std::cout << "left at: " << people.left.at("Bill Murray") << ", right at: " << people.right.at(60) << std::endl;

	//people.emplace() //<---doesn't work

	int age1 = 55; //will search for this and should get tom cruise back
	int age2 = 20; //searching for this will trigger exception
	try {
		std::cout << "\nThe person is " << people.right.at(age1) << std::endl; //tom cruise
		std::cout << "The person is " << people.right.at(age2) << std::endl; //exception time


	}
	catch (std::exception& e) {
		std::cout << "Error: " << e.what() << std::endl;
	}

	for (auto elem : people) {
		std::cout << "Left: " << elem.left << ", Right: " << elem.right << std::endl;
	}

return 0;
}