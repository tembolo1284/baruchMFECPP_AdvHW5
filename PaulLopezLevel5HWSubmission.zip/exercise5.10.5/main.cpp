#include <iostream>
#include <string>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <algorithm>
#include <functional>

namespace ublas = boost::numeric::ublas;

using Range = std::tuple<std::size_t, std::size_t>;
using Result = std::tuple<Range, bool>;

template <typename T, template <typename S, typename Alloc > class Container, typename TAlloc>
void print(const std::string& comment, const Container<T, TAlloc>& container) {
    // A generic print function for general containers
    std::cout << comment << ": ";

    // We use lambda for readability
    // a. iterators
    auto f = [](const T& t) { std::cout << t << ", "; };
    std::for_each(container.begin(), container.end(), f);
    std::cout << std::endl;

    // b. indexing
    for (std::size_t i = 0; i < container.size(); ++i) {
        std::cout << container[i] << ",";
    }
    std::cout << std::endl;
}


template <typename T>
bool greaterThan(T a, T b) { return (a > b); }

template <typename T, template <typename S, typename Alloc > class Container, typename TAlloc>
Result find_sequential_greater(const Container<T, TAlloc>& container, T x) {
    for (std::size_t j = 0; j < container.size(); ++j) {
        if (container[j] <= x && container[j + 1] > x) {
            return std::make_tuple(
                std::make_tuple(j, j + 1), true);
        }
    }
    return std::make_tuple(std::make_tuple(999, 999), false);
}

template <typename T, template <typename S, typename Alloc > class Container, typename TAlloc>
Result find_sequential_greaterFindIf(const Container<T, TAlloc>& container, T x) {

    auto predicate = [&](T a) { return a > x; };  // && ((i+1) >= x)); };
    auto result = std::find_if(begin(container), end(container), predicate);

    if (result != std::end(container)) {
        auto dist = std::distance(container.begin(), result);
        return std::make_tuple(std::make_tuple(dist - 1, dist), true);
    }
    return std::make_tuple(std::make_tuple(999, 999), false);
}

template <typename T, template <typename S, typename Alloc > class Container, typename TAlloc>
Result find_sequential_greaterUpperBound(const Container<T, TAlloc>& container, T x) {

    auto upper = std::upper_bound(container.begin(), container.end(), x); //finds first elem such that elem >= x

    if (upper != std::end(container)) {
        auto dist = std::distance(container.begin(), upper);
        return std::make_tuple(std::make_tuple(dist - 1, dist), true);
    }
    return std::make_tuple(std::make_tuple(999, 999), false);
}

template <typename T, template <typename S, typename Alloc > class Container, typename TAlloc>
Result find_sequential_greaterLowerBound(const Container<T, TAlloc>& container, T x) {

    auto lower = std::lower_bound(container.begin(), container.end(), x);

    if (lower != std::end(container)) {
        auto dist = std::distance(container.begin(), lower);
        return std::make_tuple(std::make_tuple(dist - 1, dist), true);
    }
    return std::make_tuple(std::make_tuple(999, 999), false);
}


template <typename T, template <typename S, typename Alloc > class Container, typename TAlloc>
Result find_sequential_greaterEquals(const Container<T, TAlloc>& container, T x) {

    auto equals = std::equal_range(container.begin(), container.end(), x);

    if (equals.first != container.end()) {
        auto dist = std::distance(container.begin(), equals.first);
        return std::make_tuple(std::make_tuple(dist - 1, dist), true);
    }

    return std::make_tuple(std::make_tuple(999, 999), false);
}

int main() {
    std::vector<double> vec1{ 2.0, 3.0, 4.0, -6.0 };
    print(std::string("STL"), vec1);

    ublas::vector<double> vec2(4);
    vec2[0] = 2.0; vec2[1] = 3.0; vec2[2] = 4.0; vec2[3] = -6.0;
    print(std::string("Boost"), vec2);
	//////

    std::vector<double> v1{ 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5 };
    double a = 4.2; //5.7 //6.7
    auto f1_result = find_sequential_greater(v1, a);
    std::cout << "f1 search was successful: " << std::boolalpha << std::get<1>(f1_result) << std::endl;
    std::cout << "Value is between index: " << std::get<0>(std::get<0>(f1_result)) << " and index: " << std::get<1>(std::get<0>(f1_result)) << std::endl;

    auto f2_result = find_sequential_greaterFindIf(v1, a);
    std::cout << "f2 search was successful: " << std::boolalpha << std::get<1>(f2_result) << std::endl;
    std::cout << "Value is between index: " << std::get<0>(std::get<0>(f2_result)) << " and index: " << std::get<1>(std::get<0>(f2_result)) << std::endl;

    auto f3_result = find_sequential_greaterUpperBound(v1, a);
    std::cout << "f3 search was successful: " << std::boolalpha << std::get<1>(f3_result) << std::endl;
    std::cout << "Value is between index: " << std::get<0>(std::get<0>(f3_result)) << " and index: " << std::get<1>(std::get<0>(f3_result)) << std::endl;

    auto f4_result = find_sequential_greaterLowerBound(v1, a);
    std::cout << "f4 search was successful: " << std::boolalpha << std::get<1>(f4_result) << std::endl;
    std::cout << "Value is between index: " << std::get<0>(std::get<0>(f4_result)) << " and index: " << std::get<1>(std::get<0>(f4_result)) << std::endl;

    auto f5_result = find_sequential_greaterEquals(v1, a);
    std::cout << "f5 search was successful: " << std::boolalpha << std::get<1>(f5_result) << std::endl;
    std::cout << "Value is between index: " << std::get<0>(std::get<0>(f5_result)) << " and index: " << std::get<1>(std::get<0>(f5_result)) << std::endl;
    //find if not example

    std::vector<int> v2{ 1, 2, 3, 4, 5, 6, 7, 8 };
    int n = 3;

    auto is_odd = [](int i) { return i % 2 != 0; };
    auto isItOdd = std::find_if_not(v2.begin(), v2.end(), is_odd); //will return first none odd number...which should be 2.

    if (isItOdd != v2.end()) {
        std::cout << "First none odd (or even) number found is: " << *isItOdd << std::endl;
    }
    else {
        std::cout << "All numbers were odd I'm afraid." << std::endl;
    }

	return 0;
}