#include <iostream>
#include <string>
#include <vector>
#include <algorithm>


int main() {

	std::vector<int> vec1{ 3,4,5,6,7,5,6,7,8,9,1,2,3,4 };
	std::vector<int> vec2{ 3,4,5,6,7,5,6,7,8,9,1,2,3,4 };
	std::make_heap(vec1.begin(), vec1.end());

	for (const auto& elem : vec1) {
		std::cout << elem << ' ';
	}

	std::cout << "\npop heap to move biggest elem to end: ";
	std::pop_heap(vec1.begin(), vec1.end());
	std::pop_heap(vec2.begin(), vec2.end()); //got no errors calling this even though vec2 isn't a heap

	for (const auto& elem : vec1) {
		std::cout << elem << ' ';
	}

	vec1.pop_back(); //removes biggest elem
	std::cout << "\nremoves biggest elem: ";
	for (const auto& elem : vec1) {
		std::cout << elem << ' ';
	}

	vec1.push_back(20); //inserts 20 at end of container
	std::cout << "\nadded 20 to end of container: ";
	for (const auto& elem : vec1) {
		std::cout << elem << ' ';
	}
	std::push_heap(vec1.begin(), vec1.end()); //puts the 20 in the proper spot in heap
	std::cout << "\nmoved 20 into proper place in heap: ";
	for (const auto& elem : vec1) {
		std::cout << elem << ' ';
	}
	std::push_heap(vec2.begin(), vec2.end()); //no errpr making this call to a non heap

	std::sort_heap(vec1.begin(), vec1.end());

	std::cout << "\nsorted:";
	for (const auto& i : vec1) {
		std::cout << i << ' ';
	}
	
	std::cout << "\nlargest element: ";
	std::make_heap(vec1.begin(), vec1.end());
	std::cout << vec1[0] << std::endl; //can also push head to the end and pop it like we did above


return 0;
}