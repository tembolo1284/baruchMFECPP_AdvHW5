#include <iostream>
#include <boost/regex.hpp>
#include <set>
#include <vector>
#include <string>
#include <regex>


int main() {


	std::set<std::string> result;
	std::set<int> result1;
	std::string s1 = "1,1,2,3,5,8,13,21";
	std::regex myReg("(\\d+),?");

	std::sregex_iterator iter(s1.begin(), s1.end(), myReg);
	std::sregex_iterator end = std::sregex_iterator();

	while (iter != end) {
		std::smatch match = *iter;
		std::string match_str = match.str();
		int match_int = stoi(match_str);
		std::cout << match_str << " ";
		result.insert(match_str);
		result1.insert(match_int);
		iter++;
	}

	std::cout << "\nlist string set result: ";
	for (auto elem : result) {
		std::cout << elem << " ";
	}

	std::cout << "\nlist int set result1: ";
	for (auto elem : result1) {
		std::cout << elem << " ";
	}

	return 0;
}