#include <iostream>
#include <string>
#include <cassert>
#include <boost/bimap/bimap.hpp>
#include <boost/bimap/list_of.hpp>
#include <boost/bimap/unordered_set_of.hpp>
#include <boost/bimap/multiset_of.hpp>
#include <boost/uuid/uuid.hpp>
#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <tuple>
#include <unordered_set>
#include <list>
#include <set>


using namespace boost::bimaps;

struct LEFT {};
struct RIGHT {};

int main() {
	typedef bimap<
		set_of<std::string>,  
		list_of<std::string>, 
		list_of_relation> BMType1; //D = Set, R = list

	typedef bimap<
		set_of<std::string>,
		set_of<std::string>,
		list_of_relation> BMType2; //D = Set, R = Set

	typedef bimap<
		set_of<std::string>,
		unordered_set_of<std::string>,
		list_of_relation> BMType3; //D = Set, R = UnOrdSet

	///////////////////

	typedef bimap<
		multiset_of<std::string>,
		list_of<std::string>,
		list_of_relation> BMType4; //D = MultiSet, R = list

	typedef bimap<
		multiset_of<std::string>,
		set_of<std::string>,
		list_of_relation> BMType5; //D = MultiSet, R = Set

	typedef bimap<
		multiset_of<std::string>,
		unordered_set_of<std::string>,
		list_of_relation> BMType6; //D = MultiSet, R = UnOrdSet

	///////////////////////

	typedef bimap<
		unordered_set_of<std::string>,
		list_of<std::string>,
		list_of_relation> BMType7; //D = UnOrdSet, R = list

	typedef bimap<
		unordered_set_of<std::string>,
		set_of<std::string>,
		list_of_relation> BMType8; //D = UnordSet, R = Set

	typedef bimap<
		unordered_set_of<std::string>,
		unordered_set_of<std::string>,
		list_of_relation> BMType9; //D = UnOrdSet, R = UnOrdSet

	//////////

	BMType1 bm1;
	BMType2 bm2;
	BMType3 bm3;
	BMType4 bm4;
	BMType5 bm5;
	BMType6 bm6;
	BMType7 bm7;
	BMType8 bm8;
	BMType9 bm9;

	std::set<std::string> set1 = { "This", "is", "a", "set", "of", "strings." };
	std::list<std::string> list1 = { "This", "is", "a", "list", "of", "strings."};


	
	bm2.push_back(BMType2::value_type("This","Hello"));
	bm2.push_back(BMType2::value_type("is", "to"));
	bm2.push_back(BMType2::value_type("a", "you"));
	bm2.push_back(BMType2::value_type("string.", "world!"));

	bm5.push_back(BMType2::value_type("bm5", "why"));
	bm5.push_back(BMType2::value_type("is", "so"));
	bm5.push_back(BMType2::value_type("another", "many"));
	bm5.push_back(BMType2::value_type("bimap.", "bimaps?"));

	
	for (auto i = bm2.begin(); i != bm2.end(); i++) {
		std::cout << "Left: " << i->left << ", Right: " << i->right << std::endl;
	}

	std::cout << "\n\n";
	for (auto j = bm5.begin(); j != bm5.end(); j++) {
		std::cout << "Left: " << j->left << ", Right: " << j->right << std::endl;
	}


	typedef bimap<
		set_of<std::string, std::greater<>>,
		set_of<int, std::greater<>>,
		list_of_relation> BMType10; //std::greater<> won't work for list or unordered set

	BMType10 bm10;

	bm10.push_back(BMType10::value_type("This", 1));
	bm10.push_back(BMType10::value_type("is", 2));
	bm10.push_back(BMType10::value_type("a", 3));
	bm10.push_back(BMType10::value_type("string.", 4));

	std::cout << "\n\nUsing std::greater<>" << std::endl;

	for (auto j = bm10.begin(); j != bm10.end(); j++) {
		std::cout << "Left: " << j->left << ", Right: " << j->right << std::endl;
	}





	return 0;
}