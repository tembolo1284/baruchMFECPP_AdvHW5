#include <iostream>
#include <string>
#include <boost/regex.hpp>

int main() {

	boost::regex myReg("[a-z]*");
	boost::regex myReg2("[a-z]+");

	std::string s1("aza");
	std::string s2("1");
	std::string s3("b");
	std::string s4("ZZ TOP");

	std::cout << std::boolalpha << boost::regex_match(s1, myReg) << '\n'; //true
	std::cout << std::boolalpha << boost::regex_match(s1, myReg2) << '\n'; //true

	std::cout << std::boolalpha << boost::regex_match(s2, myReg) << '\n'; //false
	std::cout << std::boolalpha << boost::regex_match(s2, myReg2) << '\n'; //false

	std::cout << std::boolalpha << boost::regex_match(s3, myReg) << '\n'; //true
	std::cout << std::boolalpha << boost::regex_match(s3, myReg2) << '\n'; //true

	std::cout << std::boolalpha << boost::regex_match(s4, myReg) << '\n'; //false
	std::cout << std::boolalpha << boost::regex_match(s4, myReg2) << "\n\n";//false

	boost::regex myNumericReg("\\d{2}");
	std::string f("34");
	std::string s("345");

	std::cout << std::boolalpha << boost::regex_match(f, myNumericReg) << '\n';//true
	std::cout << std::boolalpha << boost::regex_match(s, myNumericReg) << "\n\n";//false

	boost::regex myAltReg("(new)|(delete)");
	std::string s4A("new");
	std::string s5("delete");
	std::string s6("malloc");

	std::cout << std::boolalpha << boost::regex_match(s4A, myAltReg) << '\n';//true
	std::cout << std::boolalpha << boost::regex_match(s5, myAltReg) << '\n';//true
	std::cout << std::boolalpha << boost::regex_match(s6, myAltReg) << "\n\n";//false

	boost::regex myReg3("A*");
	boost::regex myReg4("A+");
	boost::regex myReg5("(\\d{2})");
	//regex myReg6("\\d{2, 4}");
	boost::regex myReg7("\\d{1,}");

	std::string testA("1");
	std::cout << std::boolalpha << boost::regex_match(testA, myReg3) << '\n';//false
	std::cout << std::boolalpha << boost::regex_match(testA, myReg3) << '\n';//false
	std::cout << std::boolalpha << boost::regex_match(testA, myReg3) << '\n';//false
	std::cout << std::boolalpha << boost::regex_match(testA, myReg3) << "\n\n";//false

	std::cout << std::endl;

	boost::regex rC("(\\w)*"); // Alphanumeric (word) A-Za-z0-9
	boost::regex rC1("(\\W)*"); // Not a word
	boost::regex rC2("[A-Za-z0-9_]*"); // Alphanumeric (word) A-Za-z0-9

	std::string sC1("abc");
	std::string sC2("A12678Z909za");

	std::cout << std::boolalpha << boost::regex_match(sC1, rC) << '\n';//true
	std::cout << std::boolalpha << boost::regex_match(sC1, rC1) << '\n';//false
	std::cout << std::boolalpha << boost::regex_match(sC1, rC2) << '\n';//true

	std::cout << std::boolalpha << boost::regex_match(sC2, rC) << '\n';//true
	std::cout << std::boolalpha << boost::regex_match(sC2, rC1) << '\n';//false
	std::cout << std::boolalpha << boost::regex_match(sC2, rC2) << "\n\n";//true



	return 0;
}