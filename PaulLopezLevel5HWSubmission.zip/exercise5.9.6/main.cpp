#include <iostream>
#include <string>
#include <boost/signals2/signal.hpp>

void slot1Func(double& x) {
	std::cout << "x + 2 = " << x + 2.0 <<std::endl;
}
void slot2Func(double& x) {
	std::cout << "x * 2 = " << x * 2.0 << std::endl;
}
void slot3Func(double& x) {
	std::cout << "x - 2 = " << x - 2.0 << std::endl;
}
void slot4Func(double& x) {
	std::cout << "x / 2 = " << x / 2.0 << std::endl;
}

void slotCheck(double& x) {
	if (x < 2.0 || x > 5.0) {
		x = 3;
		return;
	}
	else {
		std::cout << "x is in acceptable range." << std::endl;
	}
}

int main() {
	boost::signals2::signal<void(double& d)> signal1;
	boost::signals2::signal<void(double& d)> signal2; 
	boost::signals2::signal<void(double& d)> signal3;
	boost::signals2::signal<void(double& d)> signal4;

	boost::signals2::signal<void(double& d)> signalExterior;
	double value = -3.7; // in range [2.0, 5.0]
	
	//Exterior -> Hardware -> Data modify-> Communications


	signalExterior.connect(&slotCheck);
	signalExterior.connect(signal1);
	signalExterior.connect(signal2);
	signalExterior.connect(signal3);
	signalExterior.connect(signal4);

	signal1.connect(slot1Func);
	signal2.connect(slot2Func);
	signal3.connect(slot3Func);
	signal4.connect(slot4Func);

	signalExterior(value); //light that switch and watch it work

	// 3 + 2 = 5
	// 3 * 2 = 6
	//3 - 2 = 1
	//3 / 2 = 1.5  
	//this should be the output based on the order I called everything.

	

	return 0;
}