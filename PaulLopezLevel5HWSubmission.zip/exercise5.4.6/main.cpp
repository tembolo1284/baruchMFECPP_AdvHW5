#include <iostream>
#include <string>
#include <unordered_set>
#include <boost/functional/hash.hpp>



template <typename T>
void hash_value(std::size_t& seed, const T& val) {
	boost::hash_combine(seed, val);
	std::cout << "value: " << val << ", seed: " << seed << std::endl;
}

template <typename T, typename... Types>
void hash_value(std::size_t& seed, const T& val, const Types&... args) {
	boost::hash_combine(seed, val);
	std::cout << "value: " << val << ", seed: " << seed << std::endl;
	hash_value(seed, args...);
}

template <typename... Types>
std::size_t hash_value(const Types&... args) {
	std::size_t seed = 0;
	hash_value(seed, args...);
	return seed;
}

struct S {
    std::string f; 
    std::string s;
    S(const std::string& s1, const std::string& s2) : f(s1), s(s2) {}
};

class SHash {
public:
    std::size_t operator() (const S & s) const {
        return hash_value(s.f, s.s);
    }
};

class SEqual {
public:
	bool operator() (const S& lhs, const S& rhs) const {
		return (rhs.f == lhs.f && rhs.s == lhs.s);
	}

};

template <typename Key, typename Hash, typename EqPred>
void BucketInformation(const std::unordered_set<Key, Hash, EqPred>& b) {
	int buckCount = b.bucket_count();
	std::cout << "Num of buckets = " << buckCount << std::endl;
	std::cout << "Max num of buckets possible = " << b.max_bucket_count() << std::endl;
	std::cout << "Current load factor = " << b.load_factor() << std::endl;
	std::cout << "Max load factor possible = " << b.max_load_factor() << std::endl;

	//bucket by bucket info
	for (int i = 0; i < buckCount; i++) {
		std::cout << "Size of bucket " << i << " = " << b.bucket_size(i) << std::endl;
	}
}


int main() {
	std::unordered_set<S, SHash, SEqual> mySet;
	S s1(std::string("Hello"), std::string("to"));
	S s2(std::string("you"), std::string("today"));
	S s3(std::string("structs"), std::string("are"));
	S s4(std::string("fun"), std::string("funny"));

	mySet.insert(s1);
	mySet.insert(s2);
	mySet.insert(s3);
	mySet.insert(s4);
	BucketInformation<S, SHash, SEqual>(mySet);




	return 0;
}