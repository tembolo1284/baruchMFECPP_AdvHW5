#include <iostream>
#include <boost/signals2/signal.hpp>

template<typename T>
struct SumCombiner {
    typedef T result_type;

    template<typename InputIterator>
    T operator()(InputIterator first, InputIterator last) const {
        if (first == last) return T();
        T sum = *first++;
        while (first != last) {
            first++;
            sum += *first;
        }

        return sum;
    }
};


template <typename T>
T sumCombiner(T a, T b) {
    return a + b;
}

int main() {
    
	// Create a signal + custom combiner
    double a = 2.5;
    double b = 4.5;
	boost::signals2::signal<double(double x, double y), SumCombiner<double>> sig;

    sig.connect(&sumCombiner<double>);

    std::cout << "Sum of a + b = " << sig(a, b) << std::endl;

	return 0;
}